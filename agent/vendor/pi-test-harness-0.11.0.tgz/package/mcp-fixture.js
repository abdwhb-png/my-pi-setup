import { join } from "node:path";
import { isJsonRpcRequest, JSON_RPC_ERROR_CODES, LATEST_PROTOCOL_VERSION, SUPPORTED_PROTOCOL_VERSIONS, } from "@earendil-works/pi-mcp";
import { createInMemoryTransportPair } from "@earendil-works/pi-mcp/testing";
/** A controlled external MCP peer. Pi still owns the client, schemas and tool pipeline. */
export function createMcpFixture(options) {
    const name = options.name ?? "fixture";
    const tools = new Map();
    for (const entry of options.tools) {
        if (tools.has(entry.tool.name))
            throw new Error(`Duplicate MCP fixture tool: ${entry.tool.name}`);
        tools.set(entry.tool.name, entry);
    }
    const calls = [];
    const open = new Set();
    async function respond(request) {
        switch (request.method) {
            case "initialize": {
                const requested = request.params?.protocolVersion;
                return {
                    protocolVersion: SUPPORTED_PROTOCOL_VERSIONS.find(v => v === requested) ?? LATEST_PROTOCOL_VERSION,
                    capabilities: { tools: {} }, serverInfo: { name, version: "1.0.0" },
                };
            }
            case "tools/list": return { tools: [...tools.values()].map(entry => entry.tool) };
            case "tools/call": {
                const params = request.params;
                const toolName = params?.name ?? "";
                const args = params?.arguments ?? {};
                calls.push({ requestId: request.id, toolName, arguments: structuredClone(args) });
                const entry = tools.get(toolName);
                if (!entry)
                    return { error: { code: JSON_RPC_ERROR_CODES.invalidParams, message: `Unknown MCP fixture tool: ${toolName}` } };
                return typeof entry.response === "function" ? await entry.response(args) : entry.response;
            }
            default: return { error: { code: JSON_RPC_ERROR_CODES.methodNotFound, message: `Unsupported MCP fixture method: ${request.method}` } };
        }
    }
    return {
        calls,
        get closed() { return open.size === 0; },
        get extensionOptions() {
            const extensionOptions = {
                loadConfig(ctx) {
                    extensionOptions.logPath = join(ctx.cwd, "mcp-fixture.log");
                    return { errors: [], servers: [{ name, source: `in-memory:${name}`, scope: "extension", config: {
                                    command: "pi-test-harness-in-memory", exposure: options.exposure ?? "codemode", toolExposure: options.toolExposure,
                                } }] };
                },
                createTransport(entry) {
                    if (entry.name !== name)
                        throw new Error(`Unexpected MCP fixture server: ${entry.name}`);
                    const { client, server } = createInMemoryTransportPair();
                    open.add(server);
                    server.onClose(() => open.delete(server));
                    server.onMessage(message => {
                        if (!isJsonRpcRequest(message))
                            return;
                        void (async () => {
                            let response;
                            try {
                                response = await respond(message);
                            }
                            catch (error) {
                                response = { error: { code: JSON_RPC_ERROR_CODES.internalError, message: error instanceof Error ? error.message : String(error) } };
                            }
                            if (!open.has(server))
                                return;
                            await server.send({ jsonrpc: "2.0", id: message.id, ...(response && typeof response === "object" && "error" in response
                                    ? { error: response.error } : { result: response }) });
                        })().catch(error => { client.emitError(error); void server.close(); });
                    });
                    void server.start();
                    return client;
                },
            };
            return extensionOptions;
        },
    };
}
//# sourceMappingURL=mcp-fixture.js.map