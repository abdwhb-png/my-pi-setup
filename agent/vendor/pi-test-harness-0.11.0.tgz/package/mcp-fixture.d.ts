import type { McpExtensionOptions, McpExposure } from "@earendil-works/pi-coding-agent";
import { type CallToolResult, type JsonRpcErrorObject, type JsonRpcId, type Tool } from "@earendil-works/pi-mcp";
export type McpFixtureResponse = CallToolResult | {
    error: JsonRpcErrorObject;
};
export interface McpFixtureTool {
    tool: Tool;
    response: McpFixtureResponse | ((args: Record<string, unknown>) => McpFixtureResponse | Promise<McpFixtureResponse>);
}
export interface McpFixtureOptions {
    name?: string;
    exposure?: McpExposure;
    toolExposure?: Record<string, McpExposure>;
    tools: McpFixtureTool[];
}
export interface McpFixtureCall {
    requestId: JsonRpcId;
    toolName: string;
    arguments: Record<string, unknown>;
}
export interface McpFixture {
    /** Fresh options for each explicit createMcpExtension() composition. */
    readonly extensionOptions: McpExtensionOptions;
    /** Calls actually received by the external MCP peer, in receipt order. */
    readonly calls: McpFixtureCall[];
    /** True when no fixture transport remains open, including before connection. */
    readonly closed: boolean;
}
/** A controlled external MCP peer. Pi still owns the client, schemas and tool pipeline. */
export declare function createMcpFixture(options: McpFixtureOptions): McpFixture;
//# sourceMappingURL=mcp-fixture.d.ts.map