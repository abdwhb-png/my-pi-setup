/**
 * Tool execution interceptor — wraps tool.execute() for tools in mockTools.
 *
 * For mocked tools, the mock replaces tool.execute() and returns controlled
 * values. Extension hooks (tool_call / tool_result) are handled by
 * AgentSession's internal beforeToolCall/afterToolCall — the mock
 * must NOT re-emit them.
 *
 * For non-mocked tools, the real execute() is called and results are
 * collected for event queries.
 */
import type { AgentTool } from "@earendil-works/pi-agent-core";
import type { MockToolHandler } from "./types.js";
import type { PlaybookState } from "./playbook.js";
/**
 * Thrown when an extension hook blocks a tool call.
 * Exported for test assertions — no longer thrown by the mock itself since
 * AgentSession's beforeToolCall handles blocking before execute().
 */
export declare class ToolBlockedError extends Error {
    readonly toolBlocked: true;
    constructor(reason: string);
}
/**
 * Returns true if `err` represents a hook-based tool block.
 *
 * Kept for consumers that catch errors from tool execution flows, though
 * AgentSession's beforeToolCall blocks before execute() is reached.
 */
export declare function isBlockedError(err: unknown): boolean;
/** Shared execution replacement for request tools and native nested tool definitions. */
export declare function createMockExecute(toolName: string, handler: MockToolHandler, state: PlaybookState, mockedIds: Set<string>): AgentTool["execute"];
/** Wrap request-snapshot tools without replacing Pi's validation or hooks. */
export declare function interceptToolExecution(tools: AgentTool[], mockTools: Record<string, MockToolHandler>, playbookState: PlaybookState, propagateErrors: boolean, mockedIds: Set<string>): AgentTool[];
//# sourceMappingURL=mock-tools.d.ts.map