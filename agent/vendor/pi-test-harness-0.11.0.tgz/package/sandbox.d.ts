/**
 * Sandbox install verification — verifies npm packages work when installed clean.
 *
 * 1. npm pack → tarball
 * 2. Install in temp dir
 * 3. DefaultResourceLoader discovers extensions/skills
 * 4. Verify resources load without errors
 * 5. Optional smoke test
 */
import type { SandboxOptions, SandboxResult } from "./types.js";
/**
 * Resolve `command` to something execFileSync can actually start.
 *
 * **Why this exists**: on Windows a bare `sfw` (or `npm`) is the `.cmd` shim, and
 * child_process applies no PATHEXT when creating the process, so spawning it
 * fails with ENOENT — which broke the documented `npmCommand: ["sfw", "npm"]`
 * preset on the Windows integration matrix. Candidate extensions come from
 * PATHEXT (or the usual Windows default) and are matched against PATH in the
 * same order the platform itself would. An unmatched command is returned
 * unchanged, so a genuinely missing executable still raises a clear ENOENT.
 *
 * Exported for unit testing — not part of the public API contract.
 * @internal
 */
export declare function _resolveExecutable(command: string, platform?: NodeJS.Platform, env?: NodeJS.ProcessEnv): string;
/**
 * How to launch a resolved command, without Node's deprecated shell form.
 *
 * **Why**: on Windows a `.cmd`/`.bat` is not an executable image — it needs a
 * terminal. Since the CVE-2024-27980 fix, child_process refuses to launch one
 * with `shell: false` and fails with `EINVAL`, so resolving `sfw` to `sfw.CMD`
 * was necessary but not sufficient.
 *
 * Node documents three ways to launch it: `exec()`, `{ shell: true }`, or
 * spawning `cmd.exe` with the script as an argument. The shell option is
 * deprecated as a *runtime* warning in Node 24 (DEP0190) because an argument
 * array passed that way is only space-joined, never escaped. This takes the
 * third route — what `exec()` does internally — so the argument array reaches the
 * child intact and no deprecated form is used.
 *
 * Real binaries (`.exe`, or a path with no shim extension) spawn directly and
 * stay shell-free on every platform.
 *
 * Known limitation, unchanged from the shell form: cmd.exe applies its own
 * parsing to the arguments that follow the script, so an argument containing
 * spaces has to survive it. Only the script path is guaranteed, because Node
 * quotes an argument that contains spaces when it builds the command line.
 *
 * Exported for unit testing — not part of the public API contract.
 * @internal
 */
export declare function _spawnTarget(resolved: string, args: string[], platform?: NodeJS.Platform, env?: NodeJS.ProcessEnv): {
    command: string;
    args: string[];
};
/**
 * npm run exports .npmrc settings as environment options. npm 12 rejects
 * allow-scripts from that layer for project installs, so let it read the
 * original policy from its configuration files instead.
 * Windows environment keys can retain different casing in a copied object.
 * @internal
 */
export declare function _npmSubprocessEnv(): NodeJS.ProcessEnv;
export declare function verifySandboxInstall(options: SandboxOptions): Promise<SandboxResult>;
//# sourceMappingURL=sandbox.d.ts.map