/**
 * TestSession — orchestrates a test run with playbook, mock tools, and mock UI.
 *
 * 1. Creates a real pi environment (extensions, tools, hooks, session)
 * 2. Replaces streamFn with playbook
 * 3. Intercepts tool.execute() for mockTools
 * 4. Injects mock UI context
 * 5. Collects events
 * 6. Runs conversation script
 */
import type { TestSessionOptions, TestSession } from "./types.js";
export declare function createTestSession(options?: TestSessionOptions): Promise<TestSession>;
//# sourceMappingURL=session.d.ts.map