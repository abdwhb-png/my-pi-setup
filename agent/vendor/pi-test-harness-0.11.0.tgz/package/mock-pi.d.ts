/**
 * createMockPi — mock pi CLI for testing extensions that spawn pi as a subprocess.
 *
 * Creates a temp directory with a `pi` shim (`.cmd` on Windows, shell script on Linux)
 * that prepends to PATH. The shim invokes a mock-pi-script.mjs that reads queued
 * responses from a file-based queue. Responses are consumed in order; the last one
 * repeats when the queue is exhausted.
 *
 * ```ts
 * const mockPi = createMockPi();
 * mockPi.install();
 *
 * mockPi.onCall({ output: "Hello from agent" });
 * mockPi.onCall({ stderr: "crashed", exitCode: 1 });
 *
 * // ... test code that spawns pi ...
 *
 * mockPi.reset();
 * mockPi.uninstall();
 * ```
 */
import type { MockPi } from "./types.js";
/**
 * Create a mock pi CLI for testing extensions that spawn pi as a subprocess.
 *
 * **Concurrency constraint**: Designed for serial subprocess spawns within a single test.
 * If your test spawns multiple pi processes concurrently, responses may be consumed
 * out of order. Use separate `createMockPi()` instances for concurrent scenarios,
 * or ensure your test logic doesn't depend on response ordering.
 */
export declare function createMockPi(): MockPi;
//# sourceMappingURL=mock-pi.d.ts.map