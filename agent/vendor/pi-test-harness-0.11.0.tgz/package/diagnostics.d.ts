/**
 * Playbook diagnostic messages — clear errors when things diverge.
 */
import type { PlaybookAction } from "./types.js";
export declare function formatPlaybookDiagnostic(type: "exhausted" | "remaining", state: {
    consumed: number;
    remaining: number;
    consumedActions: PlaybookAction[];
}, remainingActions?: PlaybookAction[]): string;
export declare function formatToolError(step: number, toolName: string, error: unknown): string;
//# sourceMappingURL=diagnostics.d.ts.map