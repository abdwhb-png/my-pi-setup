/**
 * Mock UI context — intercepts ctx.ui.* calls from extensions.
 * All calls are collected for assertions. Interactive methods return
 * configured mock responses.
 */
/**
 * Create a mock ExtensionUIContext that records all calls and returns
 * configured responses.
 */
export function createMockUIContext(config = {}, uiLog) {
    function record(method, args, returnValue) {
        uiLog.push({ method, args, returnValue });
    }
    const mockUI = {
        async select(title, options, _opts) {
            let result;
            const handler = config.select;
            if (handler === undefined || handler === null) {
                result = options[0]; // default: first item
            }
            else if (typeof handler === "number") {
                result = options[handler];
            }
            else if (typeof handler === "string") {
                result = options.find((o) => o === handler) ?? options[0];
            }
            else if (typeof handler === "function") {
                result = handler(title, options);
            }
            record("select", [title, options], result);
            return result;
        },
        async confirm(title, message, _opts) {
            let result;
            const handler = config.confirm;
            if (handler === undefined || handler === null) {
                result = true; // default: approve
            }
            else if (typeof handler === "boolean") {
                result = handler;
            }
            else if (typeof handler === "function") {
                result = handler(title, message);
            }
            else {
                result = true;
            }
            record("confirm", [title, message], result);
            return result;
        },
        async input(title, placeholder, _opts) {
            let result;
            const handler = config.input;
            if (handler === undefined || handler === null) {
                result = "";
            }
            else if (typeof handler === "string") {
                result = handler;
            }
            else if (typeof handler === "function") {
                result = handler(title, placeholder);
            }
            record("input", [title, placeholder], result);
            return result;
        },
        async editor(title, prefill) {
            let result;
            const handler = config.editor;
            if (handler === undefined || handler === null) {
                result = "";
            }
            else if (typeof handler === "string") {
                result = handler;
            }
            else if (typeof handler === "function") {
                result = handler(title, prefill);
            }
            record("editor", [title, prefill], result);
            return result;
        },
        notify(message, type) {
            record("notify", [message, type]);
        },
        onTerminalInput() {
            return () => { };
        },
        setStatus(key, text) {
            record("setStatus", [key, text]);
        },
        setWorkingMessage(message) {
            record("setWorkingMessage", [message]);
        },
        setWorkingVisible(visible) {
            record("setWorkingVisible", [visible]);
        },
        setWorkingIndicator(options) {
            record("setWorkingIndicator", [options]);
        },
        setHiddenThinkingLabel(label) {
            record("setHiddenThinkingLabel", [label]);
        },
        setWidget(key, content, _options) {
            record("setWidget", [key, content]);
        },
        setFooter(...args) {
            record("setFooter", args);
        },
        setHeader(...args) {
            record("setHeader", args);
        },
        setTitle(title) {
            record("setTitle", [title]);
        },
        async custom() {
            return undefined;
        },
        pasteToEditor(text) {
            record("pasteToEditor", [text]);
        },
        setEditorText(text) {
            record("setEditorText", [text]);
        },
        getEditorText() {
            return "";
        },
        setEditorComponent(factory) {
            record("setEditorComponent", [factory]);
        },
        addAutocompleteProvider(factory) {
            record("addAutocompleteProvider", [factory]);
        },
        getEditorComponent() {
            return undefined;
        },
        get theme() {
            return {
                fg: (_color, text) => text,
                bold: (text) => text,
                italic: (text) => text,
                strikethrough: (text) => text,
            };
        },
        getAllThemes() {
            return [];
        },
        getTheme() {
            return undefined;
        },
        setTheme() {
            return { success: false, error: "Test mode" };
        },
        getToolsExpanded() {
            return false;
        },
        setToolsExpanded() { },
    };
    return mockUI;
}
//# sourceMappingURL=mock-ui.js.map