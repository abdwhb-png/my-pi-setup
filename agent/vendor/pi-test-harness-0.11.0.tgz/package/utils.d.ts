/**
 * Utility helpers for pi-test-harness consumers.
 */
/**
 * Remove a file, silently ignoring EPERM/EBUSY errors.
 *
 * **Why this exists**: On Windows, pi extensions that open SQLite databases
 * do so in the `session_start` event handler. The corresponding close happens
 * in `session_shutdown`, which is not emitted by `session.dispose()`.
 * Resources closed only by that hook can remain locked until reload or CLI
 * shutdown.
 *
 * Safe pattern in afterEach:
 * ```ts
 * afterEach(() => {
 *   safeRmSync(dbPath);
 *   safeRmSync(dbPath + "-wal");
 *   safeRmSync(dbPath + "-shm");
 * });
 * ```
 *
 * Open file handles are released when the process exits.
 * Using unique DB paths per test ensures isolation.
 */
/**
 * Returns true for errno codes that represent a Windows file-lock condition.
 * Exported for unit testing — not part of the public API contract.
 * @internal
 */
export declare function _isLockedFileError(err: unknown): boolean;
export declare function safeRmSync(filePath: string): void;
//# sourceMappingURL=utils.d.ts.map