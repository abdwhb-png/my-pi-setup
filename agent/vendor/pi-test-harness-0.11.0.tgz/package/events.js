/**
 * Event collection — passively collects all events during a test run.
 */
export function createEventCollector() {
    const all = [];
    const toolCalls = [];
    const toolResults = [];
    const messages = [];
    const ui = [];
    return {
        all,
        toolCalls,
        toolResults,
        messages,
        ui,
        toolCallsFor(name) {
            return toolCalls.filter((tc) => tc.toolName === name);
        },
        toolResultsFor(name) {
            return toolResults.filter((tr) => tr.toolName === name);
        },
        blockedCalls() {
            return toolCalls.filter((tc) => tc.blocked);
        },
        uiCallsFor(method) {
            return ui.filter((u) => u.method === method);
        },
        toolSequence() {
            return toolCalls.map((tc) => tc.toolName);
        },
    };
}
//# sourceMappingURL=events.js.map