/**
 * Mock UI context — intercepts ctx.ui.* calls from extensions.
 * All calls are collected for assertions. Interactive methods return
 * configured mock responses.
 */
import type { ExtensionUIContext } from "@earendil-works/pi-coding-agent";
import type { MockUIConfig, UICallRecord } from "./types.js";
/**
 * Create a mock ExtensionUIContext that records all calls and returns
 * configured responses.
 */
export declare function createMockUIContext(config: MockUIConfig | undefined, uiLog: UICallRecord[]): ExtensionUIContext;
//# sourceMappingURL=mock-ui.d.ts.map