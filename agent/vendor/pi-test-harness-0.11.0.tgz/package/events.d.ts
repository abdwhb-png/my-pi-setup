/**
 * Event collection — passively collects all events during a test run.
 */
import type { TestEvents } from "./types.js";
export declare function createEventCollector(): TestEvents;
//# sourceMappingURL=events.d.ts.map