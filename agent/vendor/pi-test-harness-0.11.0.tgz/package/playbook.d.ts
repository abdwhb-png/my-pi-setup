/**
 * PlaybookStreamFn — replaces the model with scripted responses.
 *
 * The playbook is a queue of actions. Each streamFn call dequeues the next
 * action and returns it as an AssistantMessageEventStream.
 */
import { type ToolCall, type AssistantMessageEventStream, type Context, type Model, type SimpleStreamOptions } from "@earendil-works/pi-ai";
import type { PlaybookAction, Turn, ToolResultRecord } from "./types.js";
/** Chainable call action builder */
declare class CallAction {
    readonly action: PlaybookAction;
    constructor(toolName: string, params: ToolCall["arguments"] | (() => ToolCall["arguments"]));
    then(callback: (result: ToolResultRecord) => void): CallAction;
}
/**
 * The model calls a tool.
 * @param toolName Tool to call
 * @param params Static params or function for late binding
 */
export declare function calls(toolName: string, params?: ToolCall["arguments"] | (() => ToolCall["arguments"])): CallAction;
/**
 * The model emits text. Agent loop ends for this turn.
 */
export declare function says(text: string): PlaybookAction;
/**
 * Define one user→model turn.
 * @param prompt The actual user prompt text
 * @param actions What the model does in response (call/say sequence)
 */
export declare function when(prompt: string, actions: Array<CallAction | PlaybookAction>): Turn;
export interface PlaybookState {
    consumed: number;
    remaining: number;
    /** The action objects for each consumed step (for diagnostics) */
    consumedActions: PlaybookAction[];
    /** Callbacks pending for completed tool calls */
    pendingCallbacks: Map<string, (result: ToolResultRecord) => void>;
}
export declare function createPlaybookStreamFn(turns: Turn[]): {
    streamFn: (model: Model<any>, context: Context, options?: SimpleStreamOptions) => AssistantMessageEventStream;
    state: PlaybookState;
};
export {};
//# sourceMappingURL=playbook.d.ts.map